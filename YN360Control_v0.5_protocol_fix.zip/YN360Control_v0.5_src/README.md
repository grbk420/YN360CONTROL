# YN360 Control v0.5

Fixes based on real YN360 testing:
- correct white-light range 0-99 from the reverse-engineered YN360 protocol
- RGB remains 0-255
- safer queued BLE writes for effects and manual commands
- longer scan/probe to find two lamps
- sliders apply changes when released
- Lamp 1 / Lamp 2 identification retained
