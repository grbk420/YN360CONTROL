# YN360 Control

Prosta aplikacja Android do sterowania dwiema starszymi lampami Yongnuo YN360 przez BLE.

## Funkcje
- osobne połączenie z Lampą 1 i Lampą 2
- sterowanie Lampą 1 / Lampą 2 / obiema
- jasność
- mieszanie ciepłej i zimnej bieli
- RGB
- ON / OFF
- POLICE
- DISCO
- STROBE
- FLASH
- COLOR FADE
- LIGHTNING
- CANDLE / FIRE
- regulacja szybkości efektów

## Budowanie APK
Repozytorium zawiera GitHub Actions workflow `.github/workflows/build-apk.yml`.
Po pushu do `main` GitHub automatycznie buduje debug APK i publikuje je jako artifact `YN360-Control-v0.2`.

## Uwaga
To wersja testowa przygotowana pod starsze YN360 BLE. Pierwszy test na fizycznych lampach zweryfikuje UUID/komendy oraz stabilność dwóch jednoczesnych połączeń.
