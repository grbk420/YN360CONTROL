package com.bongobrygada.yn360control;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private BluetoothAdapter adapter;
    private BleLightController light1, light2;
    private TextView status;
    private SeekBar brightness, whiteTemp, red, green, blue, fxSpeed;
    private RadioButton target1, target2, targetBoth;
    private final Handler fx = new Handler(Looper.getMainLooper());
    private Runnable currentFx;
    private final Random random = new Random();
    private int fadeHue = 0;

    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        status=findViewById(R.id.status);
        brightness=findViewById(R.id.brightness); whiteTemp=findViewById(R.id.whiteTemp);
        red=findViewById(R.id.red); green=findViewById(R.id.green); blue=findViewById(R.id.blue);
        fxSpeed=findViewById(R.id.fxSpeed);
        target1=findViewById(R.id.target1); target2=findViewById(R.id.target2); targetBoth=findViewById(R.id.targetBoth);

        BluetoothManager bm=(BluetoothManager)getSystemService(BLUETOOTH_SERVICE); adapter=bm.getAdapter();
        light1=new BleLightController(this, s->runOnUiThread(()->{status.setText("L1: "+s); updateButtons();}));
        light2=new BleLightController(this, s->runOnUiThread(()->{status.setText("L2: "+s); updateButtons();}));

        findViewById(R.id.connect1).setOnClickListener(v->chooseDevice(1));
        findViewById(R.id.connect2).setOnClickListener(v->chooseDevice(2));
        findViewById(R.id.onBtn).setOnClickListener(v->{stopFx(); applyWhite();});
        findViewById(R.id.offBtn).setOnClickListener(v->{stopFx(); each(BleLightController::off);});
        findViewById(R.id.whiteBtn).setOnClickListener(v->{stopFx(); applyWhite();});
        findViewById(R.id.rgbBtn).setOnClickListener(v->{stopFx(); applyRgb(red.getProgress(),green.getProgress(),blue.getProgress());});
        findViewById(R.id.policeBtn).setOnClickListener(v->startPolice());
        findViewById(R.id.discoBtn).setOnClickListener(v->startDisco());
        findViewById(R.id.strobeBtn).setOnClickListener(v->startStrobe());
        findViewById(R.id.flashBtn).setOnClickListener(v->startFlash());
        findViewById(R.id.fadeBtn).setOnClickListener(v->startFade());
        findViewById(R.id.lightningBtn).setOnClickListener(v->startLightning());
        findViewById(R.id.candleBtn).setOnClickListener(v->startCandle());
        findViewById(R.id.stopFxBtn).setOnClickListener(v->stopFx());
        requestBtPermissions();
    }

    private void updateButtons(){
        ((Button)findViewById(R.id.connect1)).setText(light1.isReady()?"Lampa 1 ✓":"Lampa 1");
        ((Button)findViewById(R.id.connect2)).setText(light2.isReady()?"Lampa 2 ✓":"Lampa 2");
    }

    private void requestBtPermissions(){
        if(Build.VERSION.SDK_INT>=31 && (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED))
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},55);
        else if(Build.VERSION.SDK_INT<31 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},56);
    }

    @SuppressWarnings("MissingPermission")
    private void chooseDevice(int slot){
        requestBtPermissions();
        if(adapter==null || !adapter.isEnabled()){ Toast.makeText(this,"Włącz Bluetooth",Toast.LENGTH_SHORT).show(); return; }
        BluetoothLeScanner scanner=adapter.getBluetoothLeScanner();
        LinkedHashMap<String,BluetoothDevice> found=new LinkedHashMap<>();
        status.setText("Skanuję BLE przez 5 sekund…");
        ScanCallback cb=new ScanCallback(){
            @Override public void onScanResult(int type, ScanResult r){
                BluetoothDevice d=r.getDevice(); String name=null; try{name=d.getName();}catch(Exception ignored){}
                boolean likely=(name!=null && (name.toUpperCase().contains("YN")||name.toUpperCase().contains("YONGNUO")));
                if(r.getScanRecord()!=null && r.getScanRecord().getServiceUuids()!=null)
                    likely |= r.getScanRecord().getServiceUuids().contains(new android.os.ParcelUuid(BleLightController.SERVICE_UUID));
                // Some old YN360 units advertise without a useful name/service UUID.
                if(likely || name==null) found.put(d.getAddress(),d);
            }
        };
        scanner.startScan(cb);
        new Handler(Looper.getMainLooper()).postDelayed(()->{
            scanner.stopScan(cb);
            if(found.isEmpty()){ status.setText("Nie znalazłem urządzeń BLE. Zbliż telefon do lampy i spróbuj ponownie."); return; }
            ArrayList<BluetoothDevice> devices=new ArrayList<>(found.values());
            String[] names=new String[devices.size()];
            for(int i=0;i<devices.size();i++){ BluetoothDevice d=devices.get(i); String n; try{n=d.getName();}catch(Exception e){n=null;} names[i]=(n==null?"Urządzenie BLE":n)+"\n"+d.getAddress(); }
            new AlertDialog.Builder(this).setTitle("Wybierz lampę "+slot).setItems(names,(dlg,which)->{
                if(slot==1) light1.connect(devices.get(which)); else light2.connect(devices.get(which));
            }).show();
        },5000);
    }

    private interface Action { void run(BleLightController l); }
    private void each(Action a){
        if(targetBoth.isChecked()||target1.isChecked()) if(light1.isReady()) a.run(light1);
        if(targetBoth.isChecked()||target2.isChecked()) if(light2.isReady()) a.run(light2);
    }
    private int scaled(int v){ return Math.max(0,Math.min(255, v*brightness.getProgress()/255)); }
    private void applyRgb(int r,int g,int b){ each(l->l.rgb(scaled(r),scaled(g),scaled(b))); }
    private void applyWhite(){ int t=whiteTemp.getProgress(); int b=brightness.getProgress(); int cool=b*t/255; int warm=b*(255-t)/255; each(l->l.white(cool,warm)); }

    private long speed(long slowMs, long fastMs){
        int p=fxSpeed.getProgress(); // 0 slow, 100 fast
        return slowMs - ((slowMs-fastMs)*p/100L);
    }

    private void stopFx(){ if(currentFx!=null) fx.removeCallbacks(currentFx); currentFx=null; status.setText("Efekt zatrzymany"); }
    private void schedule(Runnable r,long ms){ currentFx=r; fx.postDelayed(r,ms); }

    private void startPolice(){
        stopFx(); final boolean[] phase={true};
        Runnable r=new Runnable(){ public void run(){
            if(targetBoth.isChecked()){
                if(phase[0]){
                    if(light1.isReady()) light1.rgb(scaled(255),0,0);
                    if(light2.isReady()) light2.rgb(0,0,scaled(255));
                } else {
                    if(light1.isReady()) light1.rgb(0,0,scaled(255));
                    if(light2.isReady()) light2.rgb(scaled(255),0,0);
                }
            } else {
                if(phase[0]) applyRgb(255,0,0); else applyRgb(0,0,255);
            }
            phase[0]=!phase[0]; schedule(this,speed(420,90));
        }}; currentFx=r; fx.post(r); status.setText("POLICE aktywny");
    }

    private void startDisco(){
        stopFx(); Runnable r=new Runnable(){ public void run(){
            applyRgb(random.nextInt(256),random.nextInt(256),random.nextInt(256)); schedule(this,speed(700,80));
        }}; currentFx=r; fx.post(r); status.setText("DISCO aktywny");
    }

    private void startStrobe(){
        stopFx(); final boolean[] on={false}; Runnable r=new Runnable(){ public void run(){
            on[0]=!on[0]; if(on[0]) each(l->l.white(brightness.getProgress(),brightness.getProgress())); else each(BleLightController::off); schedule(this,speed(300,45));
        }}; currentFx=r; fx.post(r); status.setText("STROBE aktywny ⚠");
    }

    private void startFlash(){
        stopFx(); final int[] step={0}; Runnable r=new Runnable(){ public void run(){
            int s=step[0]++%8;
            if(s==0||s==2||s==4) each(l->l.white(brightness.getProgress(),brightness.getProgress())); else each(BleLightController::off);
            schedule(this,(s<5?speed(180,50):speed(900,220)));
        }}; currentFx=r; fx.post(r); status.setText("FLASH aktywny");
    }

    private void startFade(){
        stopFx(); fadeHue=0; Runnable r=new Runnable(){ public void run(){
            float[] hsv={fadeHue%360,1f,1f}; int c=android.graphics.Color.HSVToColor(hsv); applyRgb(android.graphics.Color.red(c),android.graphics.Color.green(c),android.graphics.Color.blue(c)); fadeHue+=4; schedule(this,speed(160,35));
        }}; currentFx=r; fx.post(r); status.setText("COLOR FADE aktywny");
    }

    private void startLightning(){
        stopFx(); final int[] burst={0};
        Runnable r=new Runnable(){ public void run(){
            if(burst[0] <= 0){
                each(BleLightController::off);
                burst[0] = 2 + random.nextInt(5);
                schedule(this, 500 + random.nextInt(1800));
            } else {
                boolean on = (burst[0] % 2 == 0);
                if(on) each(l->l.white(brightness.getProgress(), brightness.getProgress())); else each(BleLightController::off);
                burst[0]--;
                schedule(this, 35 + random.nextInt(120));
            }
        }}; currentFx=r; fx.post(r); status.setText("LIGHTNING aktywny");
    }

    private void startCandle(){
        stopFx(); Runnable r=new Runnable(){ public void run(){
            int base = Math.max(25, brightness.getProgress());
            int flicker = Math.max(5, base - random.nextInt(Math.max(6, base/3)));
            int warm = Math.min(255, flicker);
            int cool = Math.max(0, warm/8);
            each(l->l.white(cool,warm));
            schedule(this, speed(240,70));
        }}; currentFx=r; fx.post(r); status.setText("CANDLE aktywny");
    }

    @Override protected void onDestroy(){ super.onDestroy(); stopFx(); light1.disconnect(); light2.disconnect(); }
}
