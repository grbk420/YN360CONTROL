package com.bongobrygada.yn360control;

import android.bluetooth.*;
import android.content.Context;
import android.os.Build;
import java.util.UUID;

public class BleLightController {
    public static final UUID SERVICE_UUID = UUID.fromString("f000aa60-0451-4000-b000-000000000000");
    public static final UUID SEND_UUID = UUID.fromString("f000aa61-0451-4000-b000-000000000000");
    private final Context context;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic send;
    private boolean ready = false;
    private final Listener listener;

    public interface Listener { void onState(String state); }
    public BleLightController(Context c, Listener l) { context = c; listener = l; }
    public boolean isReady(){ return ready; }

    @SuppressWarnings("MissingPermission")
    public void connect(BluetoothDevice device) {
        disconnect();
        listener.onState("Łączenie: " + safeName(device));
        gatt = device.connectGatt(context, false, callback, BluetoothDevice.TRANSPORT_LE);
    }

    @SuppressWarnings("MissingPermission")
    public void disconnect(){
        ready = false; send = null;
        if(gatt != null){ gatt.disconnect(); gatt.close(); gatt = null; }
    }

    private String safeName(BluetoothDevice d){
        try { String n=d.getName(); return (n==null?d.getAddress():n+" • "+d.getAddress()); } catch(Exception e){ return d.getAddress(); }
    }

    private final BluetoothGattCallback callback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if(newState == BluetoothProfile.STATE_CONNECTED){ listener.onState("Połączono, wykrywam usługę…"); g.discoverServices(); }
            else { ready=false; listener.onState("Rozłączono"); }
        }
        @Override public void onServicesDiscovered(BluetoothGatt g, int status){
            BluetoothGattService s=g.getService(SERVICE_UUID);
            if(s==null){ listener.onState("Nie znaleziono usługi YN360"); return; }
            send=s.getCharacteristic(SEND_UUID);
            if(send==null){ listener.onState("Nie znaleziono kanału sterowania"); return; }
            ready=true; listener.onState("Gotowa ✓");
        }
    };

    @SuppressWarnings("MissingPermission")
    public synchronized void write(byte[] data){
        if(!ready || gatt==null || send==null) return;
        if(Build.VERSION.SDK_INT >= 33){ gatt.writeCharacteristic(send, data, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT); }
        else { send.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT); send.setValue(data); gatt.writeCharacteristic(send); }
    }

    public void off(){ write(new byte[]{(byte)0xAE,(byte)0xEE,0,0,0,0x56}); }
    public void rgb(int r,int g,int b){ write(new byte[]{(byte)0xAE,(byte)0xA1,(byte)r,(byte)g,(byte)b,0x56}); }
    public void white(int cool,int warm){ write(new byte[]{(byte)0xAE,(byte)0xAA,0x01,(byte)cool,(byte)warm,0x56}); }
}
