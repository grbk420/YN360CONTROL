# YN360 Control v0.3

Android controller for older Yongnuo YN360 lamps over BLE.

## v0.3 changes
- No longer shows every BLE device around you.
- Scans BLE, then actively verifies the YN360 GATT service before showing a device.
- Shows only verified YN360 candidates.
- Shows signal strength (RSSI) to help distinguish the two physical lamps.
- Remembers Lamp 1 and Lamp 2 MAC addresses and auto-reconnects on next launch.
- Prevents assigning the same lamp to both slots.
- Keeps RGB, white, brightness and effects: Police, Disco, Strobe, Flash, Color Fade, Lightning, Candle/Fire.

Known caveat: first discovery can take several seconds because the app must briefly connect to nearby BLE candidates to verify the YN360 service.


## v0.4
- pokazuje nazwę BLE z pakietu reklamowego, gdy lampa ją nadaje
- nadal weryfikuje urządzenie po usłudze GATT YN360
- sortuje urządzenia reklamujące usługę YN360 wyżej
- przyciski MIGNIJ 1 / MIGNIJ 2 do fizycznego rozpoznania lamp
- zapamiętuje nazwę i przypisanie lamp
