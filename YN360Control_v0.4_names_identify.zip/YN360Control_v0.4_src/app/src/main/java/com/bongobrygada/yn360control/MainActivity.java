package com.bongobrygada.yn360control;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private BluetoothAdapter adapter;
    private BleLightController light1, light2;
    private TextView status;
    private SeekBar brightness, whiteTemp, red, green, blue, fxSpeed;
    private RadioButton target1, target2, targetBoth;
    private final Handler fx = new Handler(Looper.getMainLooper());
    private Runnable currentFx;
    private final Random random = new Random();
    private int fadeHue = 0;
    private SharedPreferences prefs;
    private static final String PREF_L1 = "lamp1_mac";
    private static final String PREF_L2 = "lamp2_mac";
    private static final String PREF_L1_NAME = "lamp1_name";
    private static final String PREF_L2_NAME = "lamp2_name";

    private static class Candidate {
        BluetoothDevice device;
        int rssi;
        String name;
        boolean advertisesYnService;
        Candidate(BluetoothDevice d, int r, String n, boolean adv){ device=d; rssi=r; name=n; advertisesYnService=adv; }
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        prefs=getSharedPreferences("yn360", MODE_PRIVATE);
        status=findViewById(R.id.status);
        brightness=findViewById(R.id.brightness); whiteTemp=findViewById(R.id.whiteTemp);
        red=findViewById(R.id.red); green=findViewById(R.id.green); blue=findViewById(R.id.blue);
        fxSpeed=findViewById(R.id.fxSpeed);
        target1=findViewById(R.id.target1); target2=findViewById(R.id.target2); targetBoth=findViewById(R.id.targetBoth);

        BluetoothManager bm=(BluetoothManager)getSystemService(BLUETOOTH_SERVICE); adapter=bm.getAdapter();
        light1=new BleLightController(this, s->runOnUiThread(()->{status.setText("L1: "+s); updateButtons();}));
        light2=new BleLightController(this, s->runOnUiThread(()->{status.setText("L2: "+s); updateButtons();}));

        findViewById(R.id.connect1).setOnClickListener(v->chooseVerifiedLamp(1));
        findViewById(R.id.connect2).setOnClickListener(v->chooseVerifiedLamp(2));
        findViewById(R.id.identify1).setOnClickListener(v->identify(light1, "Lampa 1"));
        findViewById(R.id.identify2).setOnClickListener(v->identify(light2, "Lampa 2"));
        findViewById(R.id.onBtn).setOnClickListener(v->{stopFx(); applyWhite();});
        findViewById(R.id.offBtn).setOnClickListener(v->{stopFx(); each(BleLightController::off);});
        findViewById(R.id.whiteBtn).setOnClickListener(v->{stopFx(); applyWhite();});
        findViewById(R.id.rgbBtn).setOnClickListener(v->{stopFx(); applyRgb(red.getProgress(),green.getProgress(),blue.getProgress());});
        findViewById(R.id.policeBtn).setOnClickListener(v->startPolice());
        findViewById(R.id.discoBtn).setOnClickListener(v->startDisco());
        findViewById(R.id.strobeBtn).setOnClickListener(v->startStrobe());
        findViewById(R.id.flashBtn).setOnClickListener(v->startFlash());
        findViewById(R.id.fadeBtn).setOnClickListener(v->startFade());
        findViewById(R.id.lightningBtn).setOnClickListener(v->startLightning());
        findViewById(R.id.candleBtn).setOnClickListener(v->startCandle());
        findViewById(R.id.stopFxBtn).setOnClickListener(v->stopFx());
        requestBtPermissions();
        updateButtons();
        new Handler(Looper.getMainLooper()).postDelayed(this::autoReconnectSaved, 900);
    }

    private String shortMac(String mac){
        if(mac==null || mac.length()<8) return "";
        return mac.substring(Math.max(0, mac.length()-8));
    }

    private void updateButtons(){
        String m1=prefs.getString(PREF_L1,null), m2=prefs.getString(PREF_L2,null);
        String n1=prefs.getString(PREF_L1_NAME,"YN360"), n2=prefs.getString(PREF_L2_NAME,"YN360");
        ((Button)findViewById(R.id.connect1)).setText(light1.isReady()?"Lampa 1 ✓  "+n1:(m1!=null?"Lampa 1 • "+n1+" • "+shortMac(m1):"Lampa 1"));
        ((Button)findViewById(R.id.connect2)).setText(light2.isReady()?"Lampa 2 ✓  "+n2:(m2!=null?"Lampa 2 • "+n2+" • "+shortMac(m2):"Lampa 2"));
    }

    private boolean hasBtPermissions(){
        if(Build.VERSION.SDK_INT>=31)
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
    }

    private void requestBtPermissions(){
        if(Build.VERSION.SDK_INT>=31 && !hasBtPermissions())
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},55);
        else if(Build.VERSION.SDK_INT<31 && !hasBtPermissions())
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},56);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults){
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(hasBtPermissions()) new Handler(Looper.getMainLooper()).postDelayed(this::autoReconnectSaved, 300);
    }

    @SuppressWarnings("MissingPermission")
    private void autoReconnectSaved(){
        if(!hasBtPermissions() || adapter==null || !adapter.isEnabled()) return;
        String m1=prefs.getString(PREF_L1,null), m2=prefs.getString(PREF_L2,null);
        try { if(m1!=null) light1.connect(adapter.getRemoteDevice(m1)); } catch(Exception ignored){}
        try { if(m2!=null) light2.connect(adapter.getRemoteDevice(m2)); } catch(Exception ignored){}
    }

    @SuppressWarnings("MissingPermission")
    private void chooseVerifiedLamp(int slot){
        requestBtPermissions();
        if(!hasBtPermissions()) return;
        if(adapter==null || !adapter.isEnabled()){ Toast.makeText(this,"Włącz Bluetooth",Toast.LENGTH_SHORT).show(); return; }

        BluetoothLeScanner scanner=adapter.getBluetoothLeScanner();
        LinkedHashMap<String,Candidate> found=new LinkedHashMap<>();
        status.setText("Szukam lamp YN360…");

        ScanCallback cb=new ScanCallback(){
            @Override public void onScanResult(int type, ScanResult r){
                BluetoothDevice d=r.getDevice();
                ScanRecord sr=r.getScanRecord();
                String name=null;
                try { if(sr!=null) name=sr.getDeviceName(); } catch(Exception ignored){}
                if(name==null || name.trim().isEmpty()) { try { name=d.getName(); } catch(Exception ignored){} }
                boolean adv=false;
                try {
                    if(sr!=null && sr.getServiceUuids()!=null){
                        for(android.os.ParcelUuid u: sr.getServiceUuids()) if(BleLightController.SERVICE_UUID.equals(u.getUuid())) { adv=true; break; }
                    }
                } catch(Exception ignored){}
                Candidate old=found.get(d.getAddress());
                if(old==null || r.getRssi()>old.rssi){
                    found.put(d.getAddress(), new Candidate(d,r.getRssi(),name,adv));
                } else if(old.name==null && name!=null){ old.name=name; }
            }
        };
        scanner.startScan(cb);
        new Handler(Looper.getMainLooper()).postDelayed(()->{
            try{scanner.stopScan(cb);}catch(Exception ignored){}
            if(found.isEmpty()){ status.setText("Nie wykryto BLE. Zbliż telefon do lamp i spróbuj ponownie."); return; }
            ArrayList<Candidate> list=new ArrayList<>(found.values());
            list.sort((a,b)->{ if(a.advertisesYnService!=b.advertisesYnService) return a.advertisesYnService?-1:1; return Integer.compare(b.rssi,a.rssi); });
            // Najpierw sprawdzamy najmocniejsze sygnały. Zatrzymujemy się, gdy znajdziemy obie lampy.
            int limit=Math.min(14,list.size());
            probeSequential(slot, list.subList(0,limit), 0, new ArrayList<>());
        },3500);
    }

    @SuppressWarnings("MissingPermission")
    private void probeSequential(int slot, List<Candidate> list, int index, ArrayList<Candidate> verified){
        if(verified.size()>=2 || index>=list.size()){
            showVerifiedDialog(slot, verified);
            return;
        }
        Candidate c=list.get(index);
        status.setText("Sprawdzam urządzenia… "+(index+1)+"/"+list.size()+"   znaleziono: "+verified.size());

        final BluetoothGatt[] holder={null};
        final boolean[] finished={false};
        Runnable timeout=()->{
            if(finished[0]) return; finished[0]=true;
            try{ if(holder[0]!=null){ holder[0].disconnect(); holder[0].close(); } }catch(Exception ignored){}
            probeSequential(slot,list,index+1,verified);
        };

        BluetoothGattCallback gcb=new BluetoothGattCallback(){
            @Override public void onConnectionStateChange(BluetoothGatt g,int statusCode,int newState){
                if(finished[0]) return;
                if(statusCode==BluetoothGatt.GATT_SUCCESS && newState==BluetoothProfile.STATE_CONNECTED){
                    g.discoverServices();
                } else if(newState==BluetoothProfile.STATE_DISCONNECTED){
                    runOnUiThread(timeout);
                }
            }
            @Override public void onServicesDiscovered(BluetoothGatt g,int statusCode){
                if(finished[0]) return;
                boolean ok=false;
                if(statusCode==BluetoothGatt.GATT_SUCCESS){
                    BluetoothGattService s=g.getService(BleLightController.SERVICE_UUID);
                    ok=s!=null && s.getCharacteristic(BleLightController.SEND_UUID)!=null;
                }
                finished[0]=true;
                try{g.disconnect();g.close();}catch(Exception ignored){}
                if(ok) verified.add(c);
                final int next=index+1;
                runOnUiThread(()->probeSequential(slot,list,next,verified));
            }
        };
        try{
            holder[0]=c.device.connectGatt(this,false,gcb,BluetoothDevice.TRANSPORT_LE);
            new Handler(Looper.getMainLooper()).postDelayed(timeout,1300);
        }catch(Exception e){
            probeSequential(slot,list,index+1,verified);
        }
    }

    @SuppressWarnings("MissingPermission")
    private void showVerifiedDialog(int slot, ArrayList<Candidate> verified){
        if(verified.isEmpty()){
            status.setText("Nie znalazłem YN360. Włącz lampy i trzymaj telefon blisko nich.");
            new AlertDialog.Builder(this)
                    .setTitle("Nie znaleziono YN360")
                    .setMessage("Aplikacja sprawdziła urządzenia BLE, ale żadne nie udostępniło usługi sterowania YN360. Spróbuj ponownie z włączoną tylko jedną lampą i telefonem obok niej.")
                    .setPositiveButton("OK",null).show();
            return;
        }
        String[] names=new String[verified.size()];
        for(int i=0;i<verified.size();i++){
            Candidate c=verified.get(i);
            int bars=c.rssi>-55?3:(c.rssi>-70?2:1);
            String strength=bars==3?"bardzo blisko":(bars==2?"blisko":"słabszy sygnał");
            String shown=(c.name!=null && !c.name.trim().isEmpty())?c.name.trim():"YN360";
            names[i]=shown+"  •  "+strength+"  ("+c.rssi+" dBm)\n"+c.device.getAddress();
        }
        status.setText("Znaleziono "+verified.size()+" lampę/lampy YN360 ✓");
        new AlertDialog.Builder(this).setTitle("Wybierz lampę "+slot).setItems(names,(dlg,which)->{
            Candidate c=verified.get(which);
            String other=slot==1?prefs.getString(PREF_L2,null):prefs.getString(PREF_L1,null);
            if(other!=null && other.equals(c.device.getAddress())){
                Toast.makeText(this,"Ta lampa jest już przypisana do drugiego przycisku",Toast.LENGTH_LONG).show(); return;
            }
            String shown=(c.name!=null && !c.name.trim().isEmpty())?c.name.trim():"YN360";
            SharedPreferences.Editor ed=prefs.edit().putString(slot==1?PREF_L1:PREF_L2,c.device.getAddress());
            ed.putString(slot==1?PREF_L1_NAME:PREF_L2_NAME,shown).apply();
            if(slot==1) light1.connect(c.device); else light2.connect(c.device);
            updateButtons();
        }).setNeutralButton("Wyczyść zapisaną lampę",(d,w)->{
            prefs.edit().remove(slot==1?PREF_L1:PREF_L2).remove(slot==1?PREF_L1_NAME:PREF_L2_NAME).apply();
            if(slot==1) light1.disconnect(); else light2.disconnect();
            updateButtons();
        }).show();
    }


    private void identify(BleLightController light, String label){
        if(!light.isReady()){ Toast.makeText(this,label+" nie jest połączona",Toast.LENGTH_SHORT).show(); return; }
        stopFx();
        final int[] step={0};
        Runnable r=new Runnable(){ public void run(){
            if(step[0]>=6){ light.off(); status.setText(label+" zidentyfikowana"); return; }
            if(step[0]%2==0) light.white(255,255); else light.off();
            step[0]++;
            fx.postDelayed(this,180);
        }};
        status.setText(label+" miga 3× — sprawdź która to fizycznie lampa");
        fx.post(r);
    }

    private interface Action { void run(BleLightController l); }
    private void each(Action a){
        if(targetBoth.isChecked()||target1.isChecked()) if(light1.isReady()) a.run(light1);
        if(targetBoth.isChecked()||target2.isChecked()) if(light2.isReady()) a.run(light2);
    }
    private int scaled(int v){ return Math.max(0,Math.min(255, v*brightness.getProgress()/255)); }
    private void applyRgb(int r,int g,int b){ each(l->l.rgb(scaled(r),scaled(g),scaled(b))); }
    private void applyWhite(){ int t=whiteTemp.getProgress(); int b=brightness.getProgress(); int cool=b*t/255; int warm=b*(255-t)/255; each(l->l.white(cool,warm)); }

    private long speed(long slowMs, long fastMs){ int p=fxSpeed.getProgress(); return slowMs - ((slowMs-fastMs)*p/100L); }
    private void stopFx(){ if(currentFx!=null) fx.removeCallbacks(currentFx); currentFx=null; status.setText("Efekt zatrzymany"); }
    private void schedule(Runnable r,long ms){ currentFx=r; fx.postDelayed(r,ms); }

    private void startPolice(){
        stopFx(); final boolean[] phase={true};
        Runnable r=new Runnable(){ public void run(){
            if(targetBoth.isChecked()){
                if(phase[0]){ if(light1.isReady()) light1.rgb(scaled(255),0,0); if(light2.isReady()) light2.rgb(0,0,scaled(255)); }
                else { if(light1.isReady()) light1.rgb(0,0,scaled(255)); if(light2.isReady()) light2.rgb(scaled(255),0,0); }
            } else { if(phase[0]) applyRgb(255,0,0); else applyRgb(0,0,255); }
            phase[0]=!phase[0]; schedule(this,speed(420,90));
        }}; currentFx=r; fx.post(r); status.setText("POLICE aktywny");
    }
    private void startDisco(){ stopFx(); Runnable r=new Runnable(){ public void run(){ applyRgb(random.nextInt(256),random.nextInt(256),random.nextInt(256)); schedule(this,speed(700,80)); }}; currentFx=r; fx.post(r); status.setText("DISCO aktywny"); }
    private void startStrobe(){ stopFx(); final boolean[] on={false}; Runnable r=new Runnable(){ public void run(){ on[0]=!on[0]; if(on[0]) each(l->l.white(brightness.getProgress(),brightness.getProgress())); else each(BleLightController::off); schedule(this,speed(300,45)); }}; currentFx=r; fx.post(r); status.setText("STROBE aktywny ⚠"); }
    private void startFlash(){ stopFx(); final int[] step={0}; Runnable r=new Runnable(){ public void run(){ int s=step[0]++%8; if(s==0||s==2||s==4) each(l->l.white(brightness.getProgress(),brightness.getProgress())); else each(BleLightController::off); schedule(this,(s<5?speed(180,50):speed(900,220))); }}; currentFx=r; fx.post(r); status.setText("FLASH aktywny"); }
    private void startFade(){ stopFx(); fadeHue=0; Runnable r=new Runnable(){ public void run(){ float[] hsv={fadeHue%360,1f,1f}; int c=android.graphics.Color.HSVToColor(hsv); applyRgb(android.graphics.Color.red(c),android.graphics.Color.green(c),android.graphics.Color.blue(c)); fadeHue+=4; schedule(this,speed(160,35)); }}; currentFx=r; fx.post(r); status.setText("COLOR FADE aktywny"); }
    private void startLightning(){ stopFx(); final int[] burst={0}; Runnable r=new Runnable(){ public void run(){ if(burst[0]<=0){ each(BleLightController::off); burst[0]=2+random.nextInt(5); schedule(this,500+random.nextInt(1800)); } else { boolean on=(burst[0]%2==0); if(on) each(l->l.white(brightness.getProgress(),brightness.getProgress())); else each(BleLightController::off); burst[0]--; schedule(this,35+random.nextInt(120)); } }}; currentFx=r; fx.post(r); status.setText("LIGHTNING aktywny"); }
    private void startCandle(){ stopFx(); Runnable r=new Runnable(){ public void run(){ int base=Math.max(25,brightness.getProgress()); int flicker=Math.max(5,base-random.nextInt(Math.max(6,base/3))); int warm=Math.min(255,flicker); int cool=Math.max(0,warm/8); each(l->l.white(cool,warm)); schedule(this,speed(240,70)); }}; currentFx=r; fx.post(r); status.setText("CANDLE aktywny"); }

    @Override protected void onDestroy(){ super.onDestroy(); stopFx(); light1.disconnect(); light2.disconnect(); }
}
